<?php
ob_start();
session_start();
include("../../admin/inc/config.php");
include("../../admin/inc/functions.php");

// Getting all language variables into array as global variable
$i=1;
$statement = $pdo->prepare("SELECT * FROM tbl_language");
$statement->execute();
$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
foreach ($result as $row) {
    define('LANG_VALUE_'.$i,$row['lang_value']);
    $i++;
}

// Get M-Pesa settings from environment variables
$consumerKey = getenv('MPESA_CONSUMER_KEY');
$consumerSecret = getenv('MPESA_CONSUMER_SECRET');
$shortCode = getenv('MPESA_SHORT_CODE');
$passkey = getenv('MPESA_PASSKEY');
$callbackUrl = getenv('MPESA_CALLBACK_URL');
$businessName = getenv('MPESA_BUSINESS_NAME');

// Fallback to database if env variables are not set
if (empty($consumerKey) || empty($consumerSecret)) {
    $statement = $pdo->prepare("SELECT * FROM tbl_settings WHERE id=1");
    $statement->execute();
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row) {
        $consumerKey = $row['mpesa_consumer_key'];
        $consumerSecret = $row['mpesa_consumer_secret'];
        $shortCode = $row['mpesa_short_code'];
        $passkey = $row['mpesa_passkey'];
        $callbackUrl = $row['mpesa_callback_url'];
        $businessName = $row['mpesa_business_name'];
    }
}

// Function to get Mpesa access token
function getMpesaAccessToken($consumerKey, $consumerSecret) {
    $credentials = base64_encode($consumerKey . ':' . $consumerSecret);
    $url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
    $headers = ['Authorization: Basic ' . $credentials];

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_HEADER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($curl);
    curl_close($curl);

    $result = json_decode($response);
    return $result->access_token;
}

// Function to initiate Mpesa payment
function initiateMpesaPayment($accessToken, $shortCode, $passkey, $amount, $phoneNumber, $callbackUrl, $accountRef) {
    $timestamp = date('YmdHis');
    $password = base64_encode($shortCode . $passkey . $timestamp);
    $url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
    $headers = ['Authorization: Bearer ' . $accessToken, 'Content-Type: application/json'];

    $data = [
        'BusinessShortCode' => $shortCode,
        'Password' => $password,
        'Timestamp' => $timestamp,
        'TransactionType' => 'CustomerPayBillOnline',
        'Amount' => $amount,
        'PartyA' => $phoneNumber,
        'PartyB' => $shortCode,
        'PhoneNumber' => $phoneNumber,
        'CallBackURL' => $callbackUrl,
        'AccountReference' => $accountRef,
        'TransactionDesc' => 'Payment for order'
    ];

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($curl);
    curl_close($curl);

    return json_decode($response);
}

// Handle M-Pesa payment initiation
if (isset($_POST['amount']) && isset($_POST['phone_number'])) {
    $payment_date = date('Y-m-d H:i:s');
    $payment_id = time().rand(1000,9999); // More unique ID
    $amount = $_POST['amount'];
    $phoneNumber = $_POST['phone_number'];
    $accountRef = 'ORDER_'.$payment_id;

    // Validate phone number (should start with 2547 or 2541 and be 12 digits)
    if (!preg_match('/^254[17]\d{8}$/', $phoneNumber)) {
        $_SESSION['error_message'] = 'Invalid phone number. Please enter a valid Kenyan phone number starting with 2547 or 2541.';
        header('location: ../../mpesa_failure.php');
        exit;
    }

    try {
        // Get Mpesa access token
        $accessToken = getMpesaAccessToken($consumerKey, $consumerSecret);

        // Initiate Mpesa payment
        $mpesaResponse = initiateMpesaPayment($accessToken, $shortCode, $passkey, $amount, $phoneNumber, $callbackUrl, $accountRef);

        if (isset($mpesaResponse->ResponseCode) && $mpesaResponse->ResponseCode == '0') {
            // Insert payment record with pending status
            $statement = $pdo->prepare("INSERT INTO tbl_payment (   
                                    customer_id,
                                    customer_name,
                                    customer_email,
                                    payment_date,
                                    txnid, 
                                    paid_amount,
                                    card_number,
                                    card_cvv,
                                    card_month,
                                    card_year,
                                    bank_transaction_info,
                                    payment_method,
                                    payment_status,
                                    shipping_status,
                                    payment_id
                                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $statement->execute(array(
                                    $_SESSION['customer']['cust_id'],
                                    $_SESSION['customer']['cust_name'],
                                    $_SESSION['customer']['cust_email'],
                                    $payment_date,
                                    $mpesaResponse->CheckoutRequestID,
                                    $amount,
                                    '', 
                                    '',
                                    '', 
                                    '',
                                    $accountRef,
                                    'Mpesa',
                                    'Pending',
                                    'Pending',
                                    $payment_id
                                ));

            // Process cart items
            $i = 0;
            foreach ($_SESSION['cart_p_id'] as $key => $value) {
                $i++;
                $arr_cart_p_id[$i] = $value;
            }

            $i = 0;
            foreach ($_SESSION['cart_p_name'] as $key => $value) {
                $i++;
                $arr_cart_p_name[$i] = $value;
            }

            $i = 0;
            foreach ($_SESSION['cart_p_qty'] as $key => $value) {
                $i++;
                $arr_cart_p_qty[$i] = $value;
            }

            $i = 0;
            foreach ($_SESSION['cart_p_current_price'] as $key => $value) {
                $i++;
                $arr_cart_p_current_price[$i] = $value;
            }

            $i = 0;
            $statement = $pdo->prepare("SELECT * FROM tbl_product");
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            foreach ($result as $row) {
                $i++;
                $arr_p_id[$i] = $row['p_id'];
                $arr_p_qty[$i] = $row['p_qty'];
            }

            // Insert order items and update stock
            for ($i = 1; $i <= count($arr_cart_p_name); $i++) {
                $statement = $pdo->prepare("INSERT INTO tbl_order (
                                product_id,
                                product_name,
                                quantity, 
                                unit_price, 
                                payment_id
                                ) 
                                VALUES (?,?,?,?,?)");
                $sql = $statement->execute(array(
                                $arr_cart_p_id[$i],
                                $arr_cart_p_name[$i],
                                $arr_cart_p_qty[$i],
                                $arr_cart_p_current_price[$i],
                                $payment_id
                            ));

                // Update the stock
                for ($j = 1; $j <= count($arr_p_id); $j++) {
                    if ($arr_p_id[$j] == $arr_cart_p_id[$i]) {
                        $current_qty = $arr_p_qty[$j];
                        break;
                    }
                }
                $final_quantity = $current_qty - $arr_cart_p_qty[$i];
                $statement = $pdo->prepare("UPDATE tbl_product SET p_qty=? WHERE p_id=?");
                $statement->execute(array($final_quantity, $arr_cart_p_id[$i]));
            }
            
            // Store payment ID in session for verification
            $_SESSION['mpesa_payment_id'] = $payment_id;
            $_SESSION['mpesa_checkout_id'] = $mpesaResponse->CheckoutRequestID;
            
            // Clear cart
            unset($_SESSION['cart_p_id']);
            unset($_SESSION['cart_p_qty']);
            unset($_SESSION['cart_p_current_price']);
            unset($_SESSION['cart_p_name']);
            unset($_SESSION['cart_p_featured_photo']);

            // Redirect to waiting page
            header('location: ../../mpesa_waiting.php?payment_id='.$payment_id);
            exit;
        } else {
            // Handle Mpesa payment initiation failure
            $_SESSION['error_message'] = 'Failed to initiate M-Pesa payment. Please try again.';
            header('location: ../../mpesa_failure.php');
            exit;
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = 'An error occurred while processing your payment. Please try again.';
        header('location: ../../mpesa_failure.php');
        exit;
    }
} else if (isset($_GET['verify'])) {
    // Handle verification callback from M-Pesa
    $callbackJSONData = file_get_contents('php://input');
    $callbackData = json_decode($callbackJSONData);
    
    // Log the callback data for debugging
    file_put_contents('mpesa_callback.log', $callbackJSONData . "\n", FILE_APPEND);
    
    if (isset($callbackData->Body->stkCallback)) {
        $checkoutRequestID = $callbackData->Body->stkCallback->CheckoutRequestID;
        $resultCode = $callbackData->Body->stkCallback->ResultCode;
        $resultDesc = $callbackData->Body->stkCallback->ResultDesc;
        
        // Update payment status based on result
        if ($resultCode == 0) {
            // Payment successful
            $statement = $pdo->prepare("UPDATE tbl_payment SET 
                                payment_status=?,
                                txnid=?
                                WHERE txnid=?");
            $statement->execute(array(
                                'Completed',
                                $checkoutRequestID,
                                $checkoutRequestID
                            ));
            
            // Redirect to success page
            // Note: This is a callback, so we can't redirect. We just return a response.
        } else {
            // Payment failed
            $statement = $pdo->prepare("UPDATE tbl_payment SET 
                                payment_status=?
                                WHERE txnid=?");
            $statement->execute(array(
                                'Failed: ' . $resultDesc,
                                $checkoutRequestID
                            ));
        }
    }
    
    // Always return success to M-Pesa
    echo '{"ResultCode": 0, "ResultDesc": "Confirmation received successfully"}';
    exit;
} else {
    header('location: ../../checkout.php');
    exit;
}
?>