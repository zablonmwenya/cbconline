<?php
session_start();
include("admin/inc/config.php");

header('Content-Type: application/json');

if (!isset($_GET['payment_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Payment ID not provided']);
    exit;
}

$payment_id = $_GET['payment_id'];

try {
    $statement = $pdo->prepare("SELECT * FROM tbl_payment WHERE payment_id = ?");
    $statement->execute(array($payment_id));
    $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($result) == 0) {
        echo json_encode(['status' => 'error', 'message' => 'Payment not found']);
        exit;
    }
    
    $payment = $result[0];
    
    if ($payment['payment_status'] == 'Completed') {
        echo json_encode(['status' => 'success', 'message' => 'Payment completed successfully']);
    } else if (strpos($payment['payment_status'], 'Failed') !== false) {
        echo json_encode(['status' => 'failed', 'message' => $payment['payment_status']]);
    } else {
        echo json_encode(['status' => 'pending', 'message' => 'Payment is still pending']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'An error occurred while checking payment status']);
}
?>