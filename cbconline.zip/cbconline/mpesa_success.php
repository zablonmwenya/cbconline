<?php require_once('header.php'); ?>

<div class="page">
    <div class="container">
        <div class="row">            
            <div class="col-md-12">
                <div class="text-center">
                    <h3 style="margin-top:20px;">M-Pesa Payment Successful!</h3>
                    <p>Your payment has been processed successfully.</p>
                    <p>Order ID: <strong><?php echo $_GET['payment_id'] ?? 'N/A'; ?></strong></p>
                    <a href="dashboard.php" class="btn btn-success">View Order Details</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>