<?php require_once('header.php'); ?>

<div class="page">
    <div class="container">
        <div class="row">            
            <div class="col-md-12">
                <div class="text-center">
                    <h3>Processing Your M-Pesa Payment</h3>
                    <p>Please check your phone for the M-Pesa prompt and enter your PIN to complete the payment.</p>
                    
                    <div class="payment-status">
                        <div class="spinner-border text-primary" role="status">
                            <span class="sr-only">Processing...</span>
                        </div>
                        <p class="mt-3">Waiting for payment confirmation...</p>
                    </div>
                    
                    <div id="payment-result" style="display:none;">
                        <p id="success-message" class="text-success" style="display:none;">
                            <strong>Payment Successful!</strong> Your order has been processed.
                        </p>
                        <p id="failure-message" class="text-danger" style="display:none;">
                            <strong>Payment Failed!</strong> <span id="failure-reason"></span>
                        </p>
                        <a href="dashboard.php" class="btn btn-primary">View Order Details</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Function to check payment status
function checkPaymentStatus() {
    const urlParams = new URLSearchParams(window.location.search);
    const paymentId = urlParams.get('payment_id');
    
    if (!paymentId) {
        document.getElementById('payment-result').style.display = 'block';
        document.querySelector('.spinner-border').style.display = 'none';
        document.getElementById('failure-message').style.display = 'block';
        document.getElementById('failure-reason').textContent = 'Invalid payment request.';
        return;
    }
    
    // Make AJAX request to check payment status
    fetch('check_payment_status.php?payment_id=' + paymentId)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('payment-result').style.display = 'block';
                document.querySelector('.spinner-border').style.display = 'none';
                document.getElementById('success-message').style.display = 'block';
            } else if (data.status === 'failed') {
                document.getElementById('payment-result').style.display = 'block';
                document.querySelector('.spinner-border').style.display = 'none';
                document.getElementById('failure-message').style.display = 'block';
                document.getElementById('failure-reason').textContent = data.message;
            } else {
                // Still pending, check again in 5 seconds
                setTimeout(checkPaymentStatus, 5000);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            setTimeout(checkPaymentStatus, 5000);
        });
}

// Start checking payment status when page loads
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(checkPaymentStatus, 3000); // Start checking after 3 seconds
});
</script>

<?php require_once('footer.php'); ?>