<?php require_once('header.php'); ?>

<div class="page">
    <div class="container">
        <div class="row">            
            <div class="col-md-12">
                <div class="text-center">
                    <h3 style="margin-top:20px;">M-Pesa Payment Failed!</h3>
                    <p>Unfortunately, your payment could not be processed.</p>
                    <p>Reason: <strong><?php echo $_SESSION['error_message'] ?? 'Unknown error'; ?></strong></p>
                    <a href="checkout.php" class="btn btn-primary">Try Again</a>
                    <a href="dashboard.php" class="btn btn-secondary">View Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>