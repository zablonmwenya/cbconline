-- Add M-Pesa settings columns to tbl_settings table
ALTER TABLE `tbl_settings` 
ADD COLUMN `mpesa_consumer_key` VARCHAR(255) DEFAULT NULL,
ADD COLUMN `mpesa_consumer_secret` VARCHAR(255) DEFAULT NULL,
ADD COLUMN `mpesa_short_code` VARCHAR(50) DEFAULT NULL,
ADD COLUMN `mpesa_passkey` VARCHAR(255) DEFAULT NULL,
ADD COLUMN `mpesa_callback_url` VARCHAR(255) DEFAULT NULL,
ADD COLUMN `mpesa_business_name` VARCHAR(255) DEFAULT NULL;

-- Update existing row with default values
UPDATE `tbl_settings` SET 
`mpesa_consumer_key` = 'YOUR_CONSUMER_KEY',
`mpesa_consumer_secret` = 'YOUR_CONSUMER_SECRET',
`mpesa_short_code` = 'YOUR_SHORT_CODE',
`mpesa_passkey` = 'YOUR_PASSKEY',
`mpesa_callback_url` = 'https://yourdomain.com/payment12/mpesa/mpesa.php?verify=true',
`mpesa_business_name` = 'Your Business Name'
WHERE `id` = 1;